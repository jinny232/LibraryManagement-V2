@extends('layouts.app')

@section('title', 'Edit Member')

<style>
    /* Import a clean, modern font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    body {
        background-color: #f8f9fa; /* A light, modern off-white background */
        color: #212529; /* Dark text for readability */
        font-family: 'Inter', sans-serif; /* Clean, modern sans-serif font */
    }

    .modern-container {
        background: #ffffff;
        border: 1px solid #e9ecef;
        border-radius: 25px;
        padding: 2.5rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .modern-header h2 {
        color: #343a40;
        font-family: 'Inter', sans-serif;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }

    .modern-gradient-line {
        height: 3px;
        width: 100%;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        border-radius: 2px;
    }

    .modern-btn {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        padding: 9px 20px;
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        color: #ffffff;
        border: none;
        box-shadow: 0 4px 10px rgba(106, 17, 203, 0.2);
    }

    .modern-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(106, 17, 203, 0.3);
    }

    .modern-btn-cancel {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        padding: 9px 20px;
        background-color: #6c757d;
        color: #ffffff;
        border: none;
        box-shadow: 0 4px 10px rgba(108, 117, 125, 0.2);
    }

    .modern-btn-cancel:hover {
        background-color: #5a6268;
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(108, 117, 125, 0.3);
    }

    /* Form styling */
    .form-group {
        margin-bottom: 1.5rem;
    }

    .form-label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 0.5rem;
        display: block;
    }

    .form-control {
        display: block;
        width: 100%;
        padding: 0.75rem 1rem;
        font-size: 1rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 10px;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    .form-control:focus {
        border-color: #80bdff;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(37, 117, 252, 0.25);
    }

    /* Error message styling */
    .invalid-feedback {
        color: #dc3545;
        font-size: 0.875em;
        margin-top: 0.25rem;
    }
</style>

@section('content')
<div class="container mt-5 modern-container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="modern-header">
            <h2>Edit Member: {{ $member->name }}</h2>
            <div class="modern-gradient-line"></div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert modern-alert mb-4">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('members.update', $member->member_id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="{{ old('name', $member->name) }}" required>
            @error('name')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="roll_no" class="form-label">Roll No</label>
            <input type="text" class="form-control" id="roll_no" name="roll_no" value="{{ old('roll_no', $member->roll_no) }}" required>
            @error('roll_no')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="year" class="form-label">Year</label>
            <select class="form-control" id="year" name="year" required>
                @for ($i = 1; $i <= 5; $i++)
                    <option value="{{ $i }}" {{ old('year', $member->year) == $i ? 'selected' : '' }}>{{ $i }}</option>
                @endfor
            </select>
            @error('year')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="major" class="form-label">Major</label>
            <input type="text" class="form-control" id="major" name="major" value="{{ old('major', $member->major) }}" required>
            @error('major')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="phone_number" class="form-label">Phone Number</label>
            <input type="text" class="form-control" id="phone_number" name="phone_number" value="{{ old('phone_number', $member->phone_number) }}">
            @error('phone_number')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="registration_date" class="form-label">Registration Date</label>
            <input type="date" class="form-control" id="registration_date" name="registration_date" value="{{ old('registration_date', \Carbon\Carbon::parse($member->registration_date)->format('Y-m-d')) }}" required>
            @error('registration_date')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label for="expired_at" class="form-label">Expired Date</label>
            <input type="date" class="form-control" id="expired_at" name="expired_at" value="{{ old('expired_at', \Carbon\Carbon::parse($member->expired_at)->format('Y-m-d')) }}" required>
            @error('expired_at')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
        </div>

        <div class="d-flex justify-content-between">
            <button type="submit" class="btn modern-btn">Update Member</button>
            <a href="{{ route('members.index') }}" class="btn modern-btn-cancel">Cancel</a>
        </div>
    </form>
</div>
@endsection
