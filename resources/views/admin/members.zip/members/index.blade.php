@extends('layouts.app')

@section('title', 'Members')

<?php use Carbon\Carbon; ?>

<style>
    /* Import a clean, modern font */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    body {
        background-color: #f8f9fa;
        /* A light, modern off-white background */
        color: #212529;
        /* Dark text for readability */
        font-family: 'Inter', sans-serif;
        /* Clean, modern sans-serif font */
    }

    /* Modern Container with more rounded corners */
    .modern-container {
        background: #ffffff;
        /* Clean white background */
        border: 1px solid #e9ecef;
        border-radius: 25px;
        /* Increased for a more rounded look */
        padding: 2.5rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
        /* Soft, subtle shadow */
    }

    /* Header with Gradient Line */
    .modern-header h2 {
        color: #343a40;
        /* Dark heading color */
        font-family: 'Inter', sans-serif;
        font-weight: 700;
        margin-bottom: 0.5rem;
    }

    .modern-gradient-line {
        height: 3px;
        width: 100%;
        /* A stylish blue to purple gradient */
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        border-radius: 2px;
    }

    /* Buttons */
    .modern-btn {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        padding: 9px 10px;
        text-transform: capitalize;
        /* Main button with a vibrant gradient background */
        background: linear-gradient(90deg, #6a11cb, #2575fc);
        color: #ffffff;
        border: none;
        box-shadow: 0 4px 10px rgba(106, 17, 203, 0.2);
    }

    .modern-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(106, 17, 203, 0.3);
    }

    /* Details button with a gradient border and rounded shape */
    .modern-btn-details {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        padding: 8px 16px;
        text-transform: capitalize;
        background: #06b4f4;
        color: #ffffff;
        border: none;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        margin-right: 5px;
    }

    .modern-btn-details:hover {
        background: #0047e0;
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    /* New style for the Edit button */
    .modern-btn-edit {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        padding: 8px 16px;
        text-transform: capitalize;
        background: #ffc107;
        /* A bright, modern yellow */
        color: #ffffff;
        border: none;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        margin-right: 5px;
    }

    .modern-btn-edit:hover {
        background: #e0a800;
        /* A slightly darker yellow on hover */
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    /* New style for the Delete button */
    .modern-btn-delete {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        padding: 8px 16px;
        text-transform: capitalize;
        background: #dc3545;
        /* A vibrant red for deletion */
        color: #ffffff;
        border: none;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    }

    .modern-btn-delete:hover {
        background: #c82333;
        /* A slightly darker red on hover */
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }


    /* Table styling with more rounded corners */
    .modern-table-wrapper {
        overflow-x: auto;
        /* This enables horizontal scrolling for the table */
    }

    /* New styles to hide the scrollbar */
    /* For Webkit browsers (Chrome, Safari, Edge) */
    .modern-table-wrapper::-webkit-scrollbar {
        display: none;
    }

    /* For Firefox */
    .modern-table-wrapper {
        scrollbar-width: none;
    }

    .modern-table {
        width: 100%;
        border-collapse: collapse;
        background: #ffffff;
        border: 1px solid #e9ecef;
        border-radius: 20px;
        /* Increased for a more rounded look */
        color: #495057;
    }

    .modern-table thead {
        background-color: #f1f3f5;
        border-bottom: 2px solid #e9ecef;
    }

    .modern-table th,
    .modern-table td {
        padding: 15px;
        border: 1px solid #e9ecef;
        text-align: left;
        /* This rule prevents the text from wrapping */
        white-space: nowrap;
    }

    .modern-table th {
        color: #495057;
        font-family: 'Inter', sans-serif;
        font-weight: 600;
    }

    .modern-table tbody tr {
        transition: background-color 0.3s ease;
    }

    .modern-table tbody tr:hover {
        background-color: #f8f9fa;
    }

    /* Alerts */
    .modern-alert {
        background-color: #e9f5ff;
        color: #0d6efd;
        border: 1px solid #b3d7ff;
        border-radius: 8px;
        padding: 1rem;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }

    /* Added style for expired members to make them stand out */
    .text-danger {
        color: #dc3545 !important;
        font-weight: 600;
    }

    /* Icon styling for a 3D effect */
    .icon-wrapper {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 24px;
        height: 24px;
        margin-right: 8px;
        position: relative;
        transform: translateY(-2px);
        /* Align with text baseline */
    }

    .icon-shadow {
        position: absolute;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        transform: scale(0.9) translate(2px, 2px);
        z-index: 0;
        filter: blur(1px);
    }

    .icon-main {
        position: relative;
        z-index: 1;
    }

    /* Pagination Links */
    .pagination-container {
        display: flex;
        justify-content: center;
        margin-top: 2rem;
    }

    /* New style for the fade-out effect */
    .fade-out {
        opacity: 0;
        transition: opacity 1s ease-in-out;
    }

    /* NEW STYLES FOR SEARCH, FILTER, AND SORT */
    .filter-bar {
        display: flex;
        gap: 1rem;
        align-items: center;
        margin-bottom: 2rem;
        flex-wrap: wrap;
    }

    .filter-bar form {
        display: flex;
        gap: 1rem;
        flex-grow: 1;
        flex-wrap: wrap;
    }

    .search-input {
        flex-grow: 1;
        min-width: 200px;
        padding: 0.75rem 1rem;
        border: 1px solid #ced4da;
        border-radius: 8px;
        transition: all 0.3s;
    }

    .search-input:focus {
        outline: none;
        border-color: #6a11cb;
        box-shadow: 0 0 0 3px rgba(106, 17, 203, 0.25);
    }

    .filter-select {
        padding: 0.75rem 1rem;
        border: 1px solid #ced4da;
        border-radius: 8px;
        background-color: #fff;
        cursor: pointer;
        transition: all 0.3s;
    }

    .filter-select:focus {
        outline: none;
        border-color: #6a11cb;
        box-shadow: 0 0 0 3px rgba(106, 17, 203, 0.25);
    }

    .sortable-header a {
        display: flex;
        align-items: center;
        text-decoration: none;
        color: inherit;
        transition: color 0.3s;
    }

    .sortable-header a:hover {
        color: #6a11cb;
    }

    .sort-icon {
        margin-left: 5px;
        font-size: 1.2rem;
    }

    @media (max-width: 768px) {
        .filter-bar form {
            flex-direction: column;
            gap: 0.5rem;
        }
    }
    .chart-row {
  display: flex; /* Enables a flex container */
  justify-content: space-between; /* Distributes items with space between them */
  gap: 20px; /* Optional: Adds a gap between the columns */
  margin-bottom: 2rem;
}

.chart-column {
  flex-basis: 50%; /* Each column takes up 50% of the container width */
  max-width: 50%;
}
</style>

@section('content')
    <div class="container mt-5 modern-container">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="modern-header">
                <h2>Member List</h2>
                <div class="modern-gradient-line"></div>
            </div> 
            <a href="{{ route('members.create') }}" class="btn modern-btn">
                + Create Member
            </a>
              <input type="text" name="search" placeholder="Search by name or roll number..." class=" modern-btn flex-grow w-full md:w-auto p-2 text-gray-700 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value="{{ request('search') }}">

        </div>

        @if (session('success'))
            <div id="success-alert" class="alert modern-alert">
                {{ session('success') }}
            </div>
        @endif

        {{-- NEW: Search and Filter Controls --}}
        {{-- The form uses a GET method to submit search and filter parameters to the URL --}}
        <style>
            /* Basic styling for the filter bar to ensure visibility */
            .filter-bar {
                display: flex;
                gap: 1rem;
                align-items: center;
                padding: 1rem;
                background-color: #f3f4f6;
                /* A light gray background for the bar */
                border-radius: 0.5rem;
                margin-bottom: 1.5rem;
            }

            .search-input,
            .filter-select {
                padding: 0.75rem;
                border: 1px solid #d1d5db;
                /* Lighter border color */
                border-radius: 0.5rem;
                background-color: #fff;
                /* White background for inputs */
                color: #374151;
                /* Darker text for visibility */
                font-size: 1rem;
                flex-grow: 1;
                /* Allow inputs to grow to fill space */
            }

            /* Style for the buttons */
            .btn {
                padding: 0.75rem 1.25rem;
                border-radius: 0.5rem;
                font-weight: 600;
                text-decoration: none;
                text-align: center;
                transition: background-color 0.2s;
            }

            .modern-btn {
                background-color: #4f46e5;
                /* A vibrant button color */
                color: #fff;
                border: none;
            }

            .modern-btn:hover {
                background-color: #4338ca;
            }

            .modern-btn-details {
                background-color: #d1d5db;
                /* Lighter button for 'Clear' */
                color: #374151;
                border: none;
            }

            .modern-btn-details:hover {
                background-color: #9ca3af;
            }

            /* Ensure the form itself doesn't have styling that clashes */
            .filter-bar form {
                display: flex;
                gap: 1rem;
                width: 100%;
            }
        </style>

        <div class="p-4 bg-gray-100 rounded-lg shadow-md mb-6 flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
    <form action="{{ route('members.index') }}" method="GET" class="w-full flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-4">
        {{-- Search Input with improved styling --}}

        {{-- Filter by Major, now with improved styling and dynamic options --}}
        <select name="major" class="w-full md:w-auto p-3 text-gray-700 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Majors</option>
            {{-- This loop now uses the $majors variable passed from your controller --}}
            @foreach ($majors as $major)
                <option value="{{ $major }}" @if (request('major') == $major) selected @endif>
                    {{ $major }}
                </option>
            @endforeach
        </select>

        {{-- Filter by Year, now with improved styling and dynamic options --}}
        <select name="year" class="w-full md:w-auto p-3 text-gray-700 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Years</option>
            {{-- This loop now uses the $years variable passed from your controller --}}
            @foreach ($years as $yearString => $yearInt)
                <option value="{{ $yearString }}" @if (request('year') == $yearString) selected @endif>
                    {{ $yearString }}
                </option>
            @endforeach
        </select>

        {{-- NEW: Filter by Gender --}}
        <select name="gender" class="w-full md:w-auto p-3 text-gray-700 bg-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <option value="">All Genders</option>
            <option value="Male" @if (request('gender') == 'Male') selected @endif>Male</option>
            <option value="Female" @if (request('gender') == 'Female') selected @endif>Female</option>
        </select>

        {{-- Submit Button with modern styling --}}
        <button type="submit" class="w-full md:w-auto px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300">Apply Filters</button>

        {{-- Clear Filters Button with modern styling --}}
        <a href="{{ route('members.index') }}" class="w-full md:w-auto px-6 py-3 bg-gray-300 text-gray-800 font-bold rounded-lg hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 transition duration-300 text-center">Clear</a>
    </form>
</div>



        @push('scripts')
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script src="https://cdn.tailwindcss.com"></script>
            <script>
                // Data passed from the controller
                const majorsLabels = @json($majorsLabels);
                const majorsData = @json($majorsData);
                const yearsLabels = @json($yearsLabels);
                const yearsData = @json($yearsData);

                // Chart for Members by Major (Pie Chart)
                new Chart(document.getElementById('majorsChart'), {
                    type: 'pie',
                    data: {
                        labels: majorsLabels,
                        datasets: [{
                            label: 'Members by Major',
                            data: majorsData,
                            // Add colors, borders, etc.
                        }]
                    }
                });

                // Chart for Members by Year (Doughnut Chart)
                new Chart(document.getElementById('yearsChart'), {
                    type: 'doughnut',
                    data: {
                        labels: yearsLabels,
                        datasets: [{
                            label: 'Members by Year',
                            data: yearsData,
                            // Add colors, borders, etc.
                        }]
                    }
                });
            </script>
        @endpush

        @if ($members->count())
            <div class="modern-table-wrapper mt-4">
                <table class="table modern-table">
                    <thead>
                        <tr>
                            {{-- This column is not sortable --}}
                            <th>
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" fill="none" stroke="#6a11cb" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M12 2L2 7l10 5 10-5-10-5z"></path>
                                        <path d="M2 17l10 5 10-5"></path>
                                        <path d="M2 12l10 5 10-5"></path>
                                    </svg>
                                </span>
                                #
                            </th>
                            {{-- Sortable Name Column --}}
                            <th class="sortable-header">
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" fill="none" stroke="#2575fc" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                                        <circle cx="12" cy="7" r="4"></circle>
                                    </svg>
                                </span>
                                {{-- The link passes a 'sort' and 'direction' parameter to the URL --}}
                                <a
                                    href="{{ route('members.index', array_merge(request()->query(), ['sort' => 'name', 'direction' => request('sort') == 'name' && request('direction') == 'asc' ? 'desc' : 'asc'])) }}">
                                    Name
                                    @if (request('sort') == 'name')
                                        <span class="sort-icon">
                                            {!! request('direction') == 'asc' ? '&#9650;' : '&#9660;' !!}
                                        </span>
                                    @endif
                                </a>
                            </th>
                            {{-- Sortable Roll No Column --}}
                            <th class="sortable-header">
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" fill="none" stroke="#6a11cb" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2">
                                        </path>
                                        <rect x="8" y="2" width="8" height="4" rx="1" ry="1">
                                        </rect>
                                    </svg>
                                </span>
                                <a
                                    href="{{ route('members.index', array_merge(request()->query(), ['sort' => 'roll_no', 'direction' => request('sort') == 'roll_no' && request('direction') == 'asc' ? 'desc' : 'asc'])) }}">
                                    Roll No
                                    @if (request('sort') == 'roll_no')
                                        <span class="sort-icon">
                                            {!! request('direction') == 'asc' ? '&#9650;' : '&#9660;' !!}
                                        </span>
                                    @endif
                                </a>
                            </th>
                            {{-- Sortable Year Column --}}
                            <th class="sortable-header">
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" fill="none" stroke="#2575fc" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                        <polyline points="7 10 12 15 17 10"></polyline>
                                        <line x1="12" y1="15" x2="12" y2="3"></line>
                                    </svg>
                                </span>
                                <a
                                    href="{{ route('members.index', array_merge(request()->query(), ['sort' => 'year_string', 'direction' => request('sort') == 'year_string' && request('direction') == 'asc' ? 'desc' : 'asc'])) }}">
                                    Year
                                    @if (request('sort') == 'year_string')
                                        <span class="sort-icon">
                                            {!! request('direction') == 'asc' ? '&#9650;' : '&#9660;' !!}
                                        </span>
                                    @endif
                                </a>
                            </th>
                            {{-- Sortable Major Column --}}
                            <th class="sortable-header">
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24"
                                        height="24" viewBox="0 0 24 24" fill="none" stroke="#6a11cb"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                                    </svg>
                                </span>
                                <a
                                    href="{{ route('members.index', array_merge(request()->query(), ['sort' => 'major', 'direction' => request('sort') == 'major' && request('direction') == 'asc' ? 'desc' : 'asc'])) }}">
                                    Major
                                    @if (request('sort') == 'major')
                                        <span class="sort-icon">
                                            {!! request('direction') == 'asc' ? '&#9650;' : '&#9660;' !!}
                                        </span>
                                    @endif
                                </a>
                            </th>
                            <th>
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24"
                                        height="24" viewBox="0 0 24 24" fill="none" stroke="#2575fc"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path
                                            d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.15.93.43 1.83.83 2.69a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.86.4 1.76.68 2.69.83a2 2 0 0 1 1.72 2v3z">
                                        </path>
                                    </svg>
                                </span>
                                Phone Number
                            </th>
                            <th>
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24"
                                        height="24" viewBox="0 0 24 24" fill="none" stroke="#6a11cb"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2">
                                        </rect>
                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                    </svg>
                                </span>
                                Registered Date
                            </th>
                            <th class="sortable-header">
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24"
                                        height="24" viewBox="0 0 24 24" fill="none" stroke="#2575fc"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                                    </svg>
                                </span>
                                <a
                                    href="{{ route('members.index', array_merge(request()->query(), ['sort' => 'expired_at', 'direction' => request('sort') == 'expired_at' && request('direction') == 'asc' ? 'desc' : 'asc'])) }}">
                                    Expired Date
                                    @if (request('sort') == 'expired_at')
                                        <span class="sort-icon">
                                            {!! request('direction') == 'asc' ? '&#9650;' : '&#9660;' !!}
                                        </span>
                                    @endif
                                </a>
                            </th>
                            <th>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <span class="icon-wrapper">
                                    <svg class="icon-shadow" viewBox="0 0 24 24"></svg>
                                    <svg class="icon-main" xmlns="http://www.w3.org/2000/svg" width="24"
                                        height="24" viewBox="0 0 24 24" fill="none" stroke="#6a11cb"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <circle cx="12" cy="12" r="3"></circle>
                                        <path
                                            d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2v-2a2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z">
                                        </path>
                                    </svg>
                                </span>
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($members as $index => $member)
                            <tr>
                                <td>{{ $members->firstItem() + $index }}</td>
                                <td>{{ $member->name }}</td>
                                <td>{{ $member->roll_no }}</td>
                                {{-- Updated to use the year_string variable from the controller --}}
                                <td>{{ $member->year_string }}</td>
                                <td>{{ $member->major }}</td>
                                <td>{{ $member->phone_number ?? '-' }}</td>
                                <td>
                                    {{ Carbon::parse($member->registration_date)->format('Y-m-d') }}
                                </td>
                                <td>
                                    @if (Carbon::parse($member->expired_at)->isPast())
                                        <span
                                            class="text-danger">{{ Carbon::parse($member->expired_at)->format('Y-m-d') }}
                                            (Expired)
                                        </span>
                                    @else
                                        {{ Carbon::parse($member->expired_at)->format('Y-m-d') }}
                                    @endif
                                </td>
                                <td>
                                    {{-- Details Button --}}
                                    <a href="{{ route('members.show', $member->member_id) }}"
                                        class="btn modern-btn-details">
                                        Details
                                    </a>
                                    {{-- Edit Button --}}
                                    <a href="{{ route('members.edit', $member->member_id) }}"
                                        class="btn modern-btn-edit">
                                        Edit
                                    </a>
                                    {{-- Delete Button with a form to handle the DELETE method --}}
                                    <form action="{{ route('members.destroy', $member->member_id) }}" method="POST"
                                        style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn modern-btn-delete">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            {{-- Pagination Links --}}
            {{-- It's important to pass all filter/sort parameters to the paginator links --}}
            @if ($members->hasPages())
                <div class="pagination-container">
                    {{ $members->appends(request()->query())->links() }}
                </div>
            @endif
        @else
            <div class="alert modern-alert">
                No members found.
            </div>
        @endif
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Select the success alert element by its new ID
            const successAlert = document.getElementById('success-alert');

            // Check if the alert exists
            if (successAlert) {
                // Set a timer to hide the alert after 5000 milliseconds (5 seconds)
                setTimeout(function() {
                    // Apply a fade-out effect
                    successAlert.classList.add('fade-out');

                    // After the fade-out transition is complete, set the display to none
                    setTimeout(function() {
                        successAlert.style.display = 'none';
                    }, 1000); // This delay should match the CSS transition duration
                }, 5000);
            }
        });
    </script>
@endsection
